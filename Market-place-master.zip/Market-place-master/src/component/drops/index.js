import React from 'react'
// import Header from '../header/header'
// import Footer from '../footer/footer'
// import Drops from './Drops'
// import FixedMenu from '../header/FixedMenu'

import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const Drops = dynamic(() => import('./Drops'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
  return (
    <div>
      <Header head="headModal" cart="cartModal" />
      <FixedMenu />
      <Drops />
      <Footer />
    </div>
  )
}

export default Index