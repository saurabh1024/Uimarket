import React from 'react'
// import Header from '../header/header'
// import Footer from '../footer/footer'
// import FixedMenu from '../header/FixedMenu'
// import Offers from './Offers'

import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const Offers = dynamic(() => import('./Offers'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <Offers modalId="modal2" />
            <Footer />
        </div>
    )
}

export default Index