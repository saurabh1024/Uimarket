import React from 'react'
// import BuyItem from '../common/BuyItem'
import dynamic from 'next/dynamic';

const BuyItem = dynamic(() => import('../common/BuyItem'))
import { MdOutlineLocalOffer } from "react-icons/md";
import banner1 from '@assets/images/home/banner1.png'
import explore1 from '@assets/images/home/explore1.png'
import explore2 from '@assets/images/home/explore2.png'
import explore3 from '@assets/images/home/explore3.png'
import explore4 from '@assets/images/home/explore4.png'
import explore5 from '@assets/images/home/explore5.png'
import shadow1 from '@assets/images/home/shadow1.png'
import shadow2 from '@assets/images/home/shadow2.png'
import shadow3 from '@assets/images/home/shadow3.png'
import Image from 'next/image';

const offer_card = [
    {
        id: 1,
        image: banner1,
        title: 'Shades of Space',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 2,
        image: explore1,
        title: 'Dream Scape',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 3,
        image: explore2,
        title: 'Ether & Era',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 4,
        image: explore3,
        title: 'Shades of Space',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 5,
        image: explore4,
        title: 'Dream Scape',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 6,
        image: explore5,
        title: 'Ether & Era',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 7,
        image: explore1,
        title: 'Ether & Era',
        price: '$80',
        offer: '$72',
        off: '10%'
    },
    {
        id: 8,
        image: explore2,
        title: 'Ether & Era',
        price: '$80',
        offer: '$72',
        off: '10%'
    }
]


const Offers = ({ modalId }) => {
    return (
        <div className='offers py-[50px] relative'>
            <div className="container">
                <div className="shadows absolute d-md-block d-none left-[-60px] bottom-[-300px] rotate-[-77.84 deg] opacity-[0.64] -z-10">
                    <Image src={shadow2} alt="shadow2" />
                </div>
                <div className="shadows absolute d-md-block d-none right-[0px] bottom-[-500px] rotate-[-48.95 deg] opacity-[0.64] -z-10">
                    <Image src={shadow3} alt="shadow3" />
                </div>
                <div className="img_shadow absolute d-md-block d-none lg:top-[-80px] top-0 blur-lg right-[100px] -z-10">
                    <Image src={shadow1} alt="shadow1" />
                </div>
                <h3 className='mb-3 border-b pb-3 border-[#FFFFFF1A]'>Offers</h3>

                <div className="cards mt-5">
                    <div className="row gy-4">
                        {
                            offer_card.map((res) => {
                                return (
                                    <>
                                        <div className="col-lg-3 col-md-6" key={res.id}>
                                            <div className="card text-white relative z-10 theme_border">
                                                <div className='relative'>
                                                    <Image src={res.image} alt={res.title} className='w-100 rounded-[5px_5px_0_0]' />
                                                    <div className="offer absolute top-3 backdrop-blur-sm right-3 flex items-center bg-[#0D0B20B2] px-[16px] py-[10px] rounded-md">
                                                        <MdOutlineLocalOffer className='me-2 text-xl' /><span> {res.off} off</span>
                                                    </div>
                                                </div>
                                                <div className="card-body bg-[#0D0B20] rounded-[0_0_5px_5px]">
                                                    <p className="card-title">{res.title}</p>
                                                    <div className='flex justify-between'>
                                                        <div>
                                                            <p className="card-text font-[300] text-sm text-[#FFFFFF99] mb-0"><del>Price <span>{res.price}</span></del></p>
                                                            <p className="card-text font-[300] text-sm text-[#38B923]">Offer Price <span>{res.offer}</span></p>
                                                        </div>
                                                        <a href="#" className="theme_btn px-[20px] py-2 self-end" data-bs-toggle="modal" data-bs-target={`#${modalId}`}>Buy</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>
                    <BuyItem Ids={modalId} />
                </div>
            </div>
        </div>
    )
}

export default Offers