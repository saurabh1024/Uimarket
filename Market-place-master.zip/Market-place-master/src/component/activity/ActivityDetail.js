'use client'
import React from 'react'
import dynamic from 'next/dynamic'
import { HiOutlineBell } from "react-icons/hi2";
// import Counter from '../common/Counter';
// import ExploreDetail from '../common/ExploreDetail';
// import ActivityChart from './ActivityChart';

const Counter = dynamic(() => import('../common/Counter'))
const ExploreDetail = dynamic(() => import('../common/ExploreDetail'))
const ActivityChart = dynamic(() => import('./ActivityChart'))

import activity2 from '@assets/images/collection/activity2.png'
import cat from '@assets/images/collection/cat.png'
import shadow2 from '@assets/images/home/shadow2.png'
import shadow3 from '@assets/images/home/shadow3.png'
import verify from '@assets/images/collection/verify.png'
import Image from 'next/image';

const ActivityDetail = () => {
    return (
        <div>
            <picture>
                <source media="(min-width: 600px)" srcset="/assets/images/collection/activity1.png" />
                <Image src={activity2} className='w-100' alt="activity2" />
            </picture>
            <div className="container">
                <div className="activity_details">
                    <div className='text-center mt-[-60px]'>
                        <Image src={cat} className='mx-auto' alt="cat" />
                    </div>
                    <div className='flex items-center gap-2 justify-center my-4'>
                        <h1 className='text-[28px] mb-0'>Ghost Makers</h1>
                        <Image src={verify} alt="verify" />
                        <HiOutlineBell className='text-2xl' />
                    </div>
                    <div className="row justify-center">
                        <div className="col-lg-8">
                            <p className='text-center font-[300] text-[#9E9DA6]'>Comprising visionary artists, entrepreneurs, and creatives joining forces to forge a dynamic movement that fuses art, culture, and community, are entities such as Netflix.</p>
                            <Counter />
                        </div>
                    </div>
                </div>
            </div>
            <div className='drops py-[50px] relative'>
                <div className="container">
                    <div className="shadows absolute d-md-block d-none left-[-60px] top-[100px] rotate-[-77.84 deg] opacity-[0.64] -z-10">
                        <Image src={shadow2} alt="shadow2" />
                    </div>
                    <div className="shadows absolute d-md-block d-none right-[0px] top-[100px] rotate-[-48.95 deg] opacity-[0.64] -z-10">
                        <Image src={shadow3} alt="shadow3" />
                    </div>
                    <ul className="nav nav-pills flex-nowrap whitespace-nowrap overflow-x-auto mb-5 border-b border-[#FFFFFF1A]" id="pills-tab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button className="nav-link active" id="pills-Items-tab" data-bs-toggle="pill" data-bs-target="#pills-Items" type="button" role="tab" aria-controls="pills-Items" aria-selected="true">Items</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-Activity-tab" data-bs-toggle="pill" data-bs-target="#pills-Activity" type="button" role="tab" aria-controls="pills-Activity" aria-selected="false">Activity</button>
                        </li>
                    </ul>
                    <div className="tab-content explore" id="pills-tabContent">
                        <div className="tab-pane fade show active" id="pills-Items" role="tabpanel" aria-labelledby="pills-Items-tab" tabindex="0">
                            <ExploreDetail modalId="modal2" />
                        </div>
                        <div className="tab-pane fade" id="pills-Activity" role="tabpanel" aria-labelledby="pills-Activity-tab" tabindex="0">
                            <ActivityChart />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ActivityDetail