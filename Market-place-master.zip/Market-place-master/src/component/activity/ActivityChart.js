import React, { useState } from 'react'
import { CiFilter } from "react-icons/ci";
import { MdKeyboardArrowRight } from "react-icons/md";

import banner1 from '@assets/images/home/banner1.png'
import explore1 from '@assets/images/home/explore1.png'
import explore2 from '@assets/images/home/explore2.png'
import explore3 from '@assets/images/home/explore3.png'
import chart from '@assets/images/home/chart.png'
import Image from 'next/image';

const table_data = [
    {
        id: 1,
        type: 'Buy Now',
        img: banner1,
        item: 'Shades of Space',
        price: '$99',
    },
    {
        id: 2,
        type: 'Buy Now',
        img: explore1,
        item: 'Shades of Space',
        price: '$99',
    },
    {
        id: 3,
        type: 'Buy Now',
        img: explore2,
        item: 'Shades of Space',
        price: '$99',
    },
    {
        id: 4,
        type: 'Buy Now',
        img: explore3,
        item: 'Shades of Space',
        price: '$99',
    }
]

const ActivityChart = () => {

    const [isActive, setIsActive] = useState(false);
    const [selected, setIsSelected] = useState("Choose one");

    const [isActive1, setIsActive1] = useState(false);
    const [selected1, setIsSelected1] = useState("Choose one");

    return (
        <div className='ActivityChart preview'>
            <div className='row gy-4 items-center justify-between'>
                <div className="col-xl-9 col-lg-8 col-md-7">
                    <div className='flex items-center justify-between justify-content-md-start gap-5'>
                        <div>
                            <p className='text-[#FFFFFF99] mb-1 days'>30 Day Average Price</p>
                            <span>$45.85</span>
                        </div>
                        <div>
                            <p className='text-[#FFFFFF99] mb-1 days'>30 Day Volume</p>
                            <span>$324.4K</span>
                        </div>
                    </div>
                </div>
                <div className="col-xl-3 col-lg-4 col-md-5">
                    <div className="dropdown">
                        <div onClick={(e) => { setIsActive(!isActive); }} className="dropdown-btn space">
                            <span className='flex items-center me-3'> Time Period:</span> <p className='text-[#4D9AFF] mb-0'>{selected}</p>
                            <span className={`text-white ms-2 ${isActive ? "fas fa-chevron-up" : "fas fa-chevron-down"}`} />
                        </div>
                        <div className="dropdown-menu mt-2" style={{ display: isActive ? "block" : "none" }}>
                            <div onClick={(e) => { setIsSelected(e.target.textContent); setIsActive(!isActive); }} className="dropdown-item"> Last 6 months </div>
                            <div className="dropdown-item" onClick={(e) => { setIsSelected(e.target.textContent); setIsActive(!isActive); }}>Last 3 months</div>
                            <div className="dropdown-item" onClick={(e) => { setIsSelected(e.target.textContent); setIsActive(!isActive); }}>Last 8 months</div>
                            <div className="dropdown-item" onClick={(e) => { setIsSelected(e.target.textContent); setIsActive(!isActive); }}>Last 1 months</div>
                            <div className="dropdown-item" onClick={(e) => { setIsSelected(e.target.textContent); setIsActive(!isActive); }}>Last 2 months</div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='mt-5'>
                <Image src={chart} alt="chart" className='mx-auto' />
            </div>

            <div className='col-xl-3 col-md-4 mt-5'>
                <div className="dropdown">
                    <div onClick={(e) => { setIsActive1(!isActive1); }} className="dropdown-btn space">
                        <span className='flex items-center me-3'><CiFilter className='text-xl me-2' /> Filter :</span> <p className='text-[#4D9AFF] mb-0'>{selected1}</p>
                        <span className={`text-white ms-2 ${isActive1 ? "fas fa-chevron-up" : "fas fa-chevron-down"}`} />
                    </div>
                    <div className="dropdown-menu mt-2" style={{ display: isActive1 ? "block" : "none" }}>
                        <div onClick={(e) => { setIsSelected1(e.target.textContent); setIsActive1(!isActive1); }} className="dropdown-item"> Type </div>
                        <div className="dropdown-item" onClick={(e) => { setIsSelected1(e.target.textContent); setIsActive1(!isActive1); }}>Item</div>
                        <div className="dropdown-item" onClick={(e) => { setIsSelected1(e.target.textContent); setIsActive1(!isActive1); }}>Price</div>
                        <div className="dropdown-item " onClick={(e) => { setIsSelected1(e.target.textContent); setIsActive1(!isActive1); }}> <div className='flex items-center'>From <MdKeyboardArrowRight /> To </div> </div>
                        <div className="dropdown-item" onClick={(e) => { setIsSelected1(e.target.textContent); setIsActive1(!isActive1); }}>Time</div>
                    </div>
                </div>
            </div>
            <div className='activity_table mt-5 table-responsive d-sm-block d-none'>
                <table className='font-[300] w-100'>
                    <thead>
                        <tr>
                            <td scope="col" className='min-w-[100px]'>Type</td>
                            <td scope="col" className='min-w-[300px]'>Item</td>
                            <td scope="col" className='min-w-[250px]'>Price</td>
                            <td scope="col" className='min-w-[150px]'>From <MdKeyboardArrowRight /> To</td>
                            <td scope="col" className='min-w-[150px]'>Time</td>
                            <td scope="col" className='min-w-[150px]'></td>
                        </tr>
                    </thead>
                    <tbody className='table_info'>
                        {
                            table_data.map((res, index) => {
                                return (
                                    <>
                                        <tr key={index} style={{ marginBottom: '10px' }} className='align-middle'>
                                            <td className='text-[#C4C4C4]'>{res.type}</td>
                                            <td className='flex items-center'>
                                                <Image src={res.img} className='w-[85px] rounded-[5px]' alt={res.item} />
                                                <div className='ms-3'>
                                                    <p className='mb-1 text-[#C4C4C4]'>{res.item}</p>
                                                    <span>#5835</span>
                                                </div>
                                            </td>
                                            <td>
                                                <span className='mb-1 block'>{res.price}</span>
                                                <p className='mb-1 text-[#38B923]'>98% above floor price</p>
                                                <span className='text-[#C4C4C4]'>10% royalty</span>
                                            </td>
                                            <td>
                                                <p className='mb-1 text-[#4D9AFF]'>Avonika</p>
                                                <p className='mb-1'><MdKeyboardArrowRight /></p>
                                                <p className='mb-0 text-[#4D9AFF]'>Bazaro</p>
                                            </td>
                                            <td className='text-[#C4C4C4]'>2 hours ago</td>
                                            <td className='text-end'><a href="#" className='theme_btn px-4 py-2'>Buy now</a></td>
                                        </tr>
                                    </>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
            <div className='mt-4 d-sm-none'>
                <div className="row">
                    {
                        table_data.map((res) => {
                            return (
                                <div className="col-12">
                                    <div className='mb-4 border-b border-b-[#FFFFFF2B] pb-4 font-[300]'>
                                        <p>Item</p>
                                        <div className='flex items-center mb-4'>
                                            <Image src={res.img} className='w-[85px] rounded-[5px]' alt={res.item} />
                                            <div className='ms-3'>
                                                <p className='mb-1 text-[#C4C4C4]'>{res.item}</p>
                                                <span>#5835</span>
                                                <p className='mb-0 mt-2'>Type: <span className='text-[#C4C4C4]'>{res.type}</span></p>
                                            </div>
                                        </div>
                                        <div className='flex items-center mb-2'>
                                            <p className='mb-0'>Price :</p>
                                            <span className='text-[#C4C4C4] ms-2'>{res.price}</span>
                                            <p className='ms-2 mb-0 text-[#38B923]'>98% above floor price</p>
                                        </div>
                                        <div className='flex items-center mb-2'>
                                            <p className='mb-0'>Royalty : </p>
                                            <span className='text-[#C4C4C4] ms-2'>10%</span>
                                        </div>
                                        <div className='flex items-center mb-2'>
                                            <p className='mb-0 flex items-center'>From <MdKeyboardArrowRight />To :</p>
                                            <p className='ms-2 flex items-center mb-0 text-[#4D9AFF]'>Avonika <MdKeyboardArrowRight /> Bazaro</p>
                                        </div>
                                        <div className='flex items-center mb-2'>
                                            <p className='mb-0'>Royalty : </p>
                                            <span className='text-[#C4C4C4] ms-2'>2 hours ago</span>
                                        </div>
                                        <a className='theme_btn w-100 text-center py-2' href="#">Buy now</a>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    )
}

export default ActivityChart