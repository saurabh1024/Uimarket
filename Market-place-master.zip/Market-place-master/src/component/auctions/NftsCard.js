import React from 'react'
import banner1 from '@assets/images/home/banner1.png'
import explore1 from '@assets/images/home/explore1.png'
import explore2 from '@assets/images/home/explore2.png'
import explore3 from '@assets/images/home/explore3.png'
import user from '@assets/images/offer/user.png'
import Image from 'next/image'

const auctions_card = [
    {
        id: 1,
        image: banner1,
        title: 'Shades of Space',
        time: '10d : 20h : 10m : 25s',
        name: 'By David_Millan',
        highbid: '$450.90'
    },
    {
        id: 2,
        image: explore1,
        title: 'Dream Scape',
        time: '10d : 20h : 10m : 25s',
        name: 'By David_Millan',
        highbid: '$450.90'
    },
    {
        id: 3,
        image: explore2,
        title: 'Ether & Era',
        time: '10d : 20h : 10m : 25s',
        name: 'By David_Millan',
        highbid: '$450.90'
    },
    {
        id: 4,
        image: explore3,
        title: 'Shades of Space',
        time: '10d : 20h : 10m : 25s',
        name: 'By David_Millan',
        highbid: '$450.90'
    },
]


const NftsCard = () => {
    return (
        <div className="row gy-4 justify-content-center">
            {
                auctions_card.map((res) => {
                    return (
                        <>
                            <div className="col-lg-3 col-md-6" key={res.id}>
                                <div className="cards theme_border">
                                    <div className='relative'>
                                        <Image src={res.image} className='w-100 rounded-[5px_5px_0_0]' alt={res.title} />
                                        <div className="card_layer flex justify-center w-100">
                                            <p className='mb-0 text-[#FFFFFF99] bg-[#000000B2] py-2 px-4 rounded-md font-[300]'>{res.time}</p>
                                        </div>
                                    </div>
                                    <div className="auction_info p-3 bg-[#0D0B20] rounded-[0_0_5px_5px]">
                                        <div className='flex items-center gap-3 border-b border-[#FFFFFF1A] pb-3'>
                                            <Image src={user} alt="user" />
                                            <div>
                                                <p className='mb-0 flex items-center'>{res.title}</p>
                                                <span className='theme_text text-sm'>{res.name}</span>
                                            </div>
                                        </div>
                                        <div className='flex items-center justify-between text-sm pt-3'>
                                            <p className='mb-0'>Highest bid</p>
                                            <span>{res.highbid}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    )
                })
            }
        </div>
    )
}

export default NftsCard