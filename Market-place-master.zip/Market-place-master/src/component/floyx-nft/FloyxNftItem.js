import Link from 'next/link'
import React from 'react'
import shadow1 from '@assets/images/home/shadow1.png'
import floyx1 from '@assets/images/offer/floyx1.jpg'
import floyx2 from '@assets/images/offer/floyx2.jpg'
import Image from 'next/image';

const FloyxNftItem = () => {
    return (
        <div className='floyx_nft py-[50px] relative'>
            <div className="container">
                <div className="img_shadow absolute d-md-block d-none lg:top-[-80px] top-0 blur-lg right-[100px] -z-10">
                    <Image src={shadow1} alt="shadow1" />
                </div>

                <h3 className='mb-5 border-b pb-3 border-[#FFFFFF1A]'>Floyx NFT Staking </h3>
                <div className="row gy-4">
                    <div className="col-lg-6">
                        <div className="floyx_card relative overflow-hidden">
                            <Image src={floyx1} className='w-100 h-100 rounded-md' alt="floyx1" />
                            <div className="layer rounded-md absolute top-0 left-0 w-full h-full bg-black/60 flex items-center justify-center text-center">
                                <div>
                                    <h1 className='sm:text-[28px] text-[20px]'>Upgrade your NFT</h1>
                                    <Link href="/floyx-nft/upgrade-nft" className='py-sm-3 py-2 w-[132px] text-white rounded px-8 inline-block'>Upgrade</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="floyx_card relative overflow-hidden h-100">
                            <Image src={floyx2} className='w-100 h-100 rounded-md' alt="floyx2" />
                            <div className="layer rounded-md absolute top-0 left-0 w-full h-full bg-black/60 flex items-center justify-center text-center">
                                <div>
                                    <h1 className='sm:text-[28px] text-[20px]'>Stake your NFT</h1>
                                    <Link href="/floyx-nft/stack-nft" className='py-sm-3 py-2 w-[132px] text-white rounded px-8 inline-block'>Stack</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default FloyxNftItem