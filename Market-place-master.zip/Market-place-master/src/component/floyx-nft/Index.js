import React from 'react'
// import Header from '../header/header'
// import Footer from '../footer/footer'
// import FixedMenu from '../header/FixedMenu'
// import FloyxNftItem from './FloyxNftItem'
import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const FloyxNftItem = dynamic(() => import('./FloyxNftItem'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <FloyxNftItem />
            <Footer />
        </div>
    )
}

export default Index