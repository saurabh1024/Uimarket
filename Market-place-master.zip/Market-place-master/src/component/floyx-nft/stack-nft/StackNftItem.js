import dynamic from 'next/dynamic'
import React from 'react'
// import NftStaking from './NftStaking'
// import Rewards from './Rewards'

const NftStaking = dynamic(() => import('./NftStaking'))
const Rewards = dynamic(() => import('./Rewards'))

const StackNftItem = () => {
    return (
        <div>
            <div className='drops py-[50px] relative'>
                <div className="container">
                    <ul className="nav nav-pills flex-nowrap mb-5 border-b border-[#FFFFFF1A]" id="pills-tab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button className="nav-link active" id="pills-stack-tab" data-bs-toggle="pill" data-bs-target="#pills-stack" type="button" role="tab" aria-controls="pills-stack" aria-selected="true">Floyx NFT Staking</button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button className="nav-link" id="pills-reward-tab" data-bs-toggle="pill" data-bs-target="#pills-reward" type="button" role="tab" aria-controls="pills-reward" aria-selected="false"> My Rewards</button>
                        </li>
                    </ul>
                    <div className="tab-content" id="pills-tabContent">
                        <div className="tab-pane fade show active" id="pills-stack" role="tabpanel" aria-labelledby="pills-stack-tab" tabindex="0">
                            <NftStaking />
                        </div>
                        <div className="tab-pane fade" id="pills-reward" role="tabpanel" aria-labelledby="pills-reward-tab" tabindex="0">
                            <Rewards />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default StackNftItem