import React from 'react'
// import Header from '../../header/header'
// import FixedMenu from '../../header/FixedMenu'
// import Footer from '../../footer/footer'
// import StackNftItem from './StackNftItem'
import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../../header/header'))
const FixedMenu = dynamic(() => import('../../header/FixedMenu'))
const StackNftItem = dynamic(() => import('./StackNftItem'))
const Footer = dynamic(() => import('../../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <StackNftItem />
            <Footer />
        </div>
    )
}

export default Index