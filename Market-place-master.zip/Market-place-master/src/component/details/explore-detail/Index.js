import React from 'react'
// import Header from '../../header/header'
// import FixedMenu from '../../header/FixedMenu'
// import Footer from '../../footer/footer'
// import ExploreItem from './ExploreItem'
import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../../header/header'))
const FixedMenu = dynamic(() => import('../../header/FixedMenu'))
const ExploreItem = dynamic(() => import('./ExploreItem'))
const Footer = dynamic(() => import('../../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <ExploreItem />
            <Footer />
        </div>
    )
}

export default Index