import React from 'react'
// import Header from '../../header/header'
// import FixedMenu from '../../header/FixedMenu'
// import Footer from '../../footer/footer'
// import CollectionItems from './CollectionItems'

import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../../header/header'))
const FixedMenu = dynamic(() => import('../../header/FixedMenu'))
const CollectionItems = dynamic(() => import('./CollectionItems'))
const Footer = dynamic(() => import('../../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <CollectionItems />
            <Footer />
        </div>
    )
}

export default Index