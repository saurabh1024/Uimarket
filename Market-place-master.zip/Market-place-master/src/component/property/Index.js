import React from 'react'
// import Header from '../header/header'
// import MenuBar from '../header/MenuBar'
// import FixedMenu from '../header/FixedMenu'
// import Footer from '../footer/footer'
// import PropertyDetail from './PropertyDetail'

import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const MenuBar = dynamic(() => import('../header/MenuBar'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const PropertyDetail = dynamic(() => import('./PropertyDetail'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <MenuBar />
            <FixedMenu />
            <PropertyDetail />
            <Footer />
        </div>
    )
}

export default Index