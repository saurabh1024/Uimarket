import React, { useState } from 'react';
import DatePicker from "react-datepicker";
import 'react-datepicker/dist/react-datepicker.css';
import image6 from '@assets/images/create/image 6.png'
import image7 from '@assets/images/create/image 7.png'
import image8 from '@assets/images/create/image 8.png'
import image9 from '@assets/images/create/image 9.png'
import image10 from '@assets/images/create/image 10.png'
import Image from 'next/image'

const AuctionForm = () => {

    const [startDate, setStartDate] = useState(new Date());

    const [isActive, setIsActive] = useState(false);
    const [selected, setSelected] = useState({
        text: "ETH",
        image: '/assets/images/create/image 7.png'
    });

    const [isActive1, setIsActive1] = useState(false);
    const [selected1, setSelected1] = useState({
        text: "ETH",
        image: '/assets/images/create/image 7.png'
    });

    const handleDropdownItemClick = (text, image) => {
        setSelected({ text, image });
        setIsActive(false);
    }

    const handleDropdownItemClick1 = (text, image) => {
        setSelected1({ text, image });
        setIsActive1(false);
    }


    return (
        <div>
            <form>
                <p className='mt-4'>Starting price</p>
                <div className="row gx-md-4 gx-2">
                    <div className="col-md-3 col-6">
                        <div className="dropdown">
                            <div onClick={() => setIsActive(!isActive)} className="dropdown-btn">
                                <span className='text-[#4D9AFF] flex items-center'>
                                    <img src={selected.image} alt={selected.text} className='me-2' />
                                    {selected.text}
                                </span>
                                <span className={`text-white ${isActive ? "fas fa-chevron-up" : "fas fa-chevron-down"}`} />
                            </div>
                            <div className="dropdown-menu mt-2" style={{ display: isActive ? "block" : "none" }}>
                                <div className="dropdown-item" onClick={() => handleDropdownItemClick("Bitcoin", "/assets/images/create/image 6.png")}>
                                    <div className='flex items-center'>
                                        <Image src={image6} className='me-2' alt="Bitcoin" />Bitcoin
                                    </div>
                                </div>
                                <div className="dropdown-item" onClick={() => handleDropdownItemClick("ETH", "/assets/images/create/image 7.png")}>
                                    <div className='flex items-center'>
                                        <Image src={image7} className='me-2' alt="ETH" />ETH
                                    </div>
                                </div>
                                <div className="dropdown-item" onClick={() => handleDropdownItemClick("Cardano", "/assets/images/create/image 8.png")}>
                                    <div className='flex items-center'>
                                        <Image src={image8} className='me-2' alt="Cardano" />Cardano
                                    </div>
                                </div>
                                <div className="dropdown-item" onClick={() => handleDropdownItemClick("Solona", "/assets/images/create/image 9.png")}>
                                    <div className='flex items-center'>
                                        <Image src={image9} className='me-2' alt="Solona" />Solona
                                    </div>
                                </div>
                                <div className="dropdown-item" onClick={() => handleDropdownItemClick("Binance", "/assets/images/create/image 10.png")}>
                                    <div className='flex items-center'>
                                        <Image src={image10} className='me-2' alt="Binance" />Binance
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-9 col-6">
                        <input type="text" placeholder='0.058' className='py-[11px] px-4 w-100 bg-[#1B1830] rounded border-0 outline-none' />
                        <label htmlFor="" className='text-end block mt-3 text-[#9E9DA6CC]'>$860.00</label>
                    </div>
                </div>
                <div className='mt-4'>
                    <p>Duration</p>
                    <DatePicker
                        showIcon
                        selected={startDate}
                        onChange={(date) => setStartDate(date)}
                        className='w-100 bg-[#1B1830] rounded outline-none'
                    />
                </div>
                <div className='mt-5'>
                    <div className="form-check">
                        <input className="form-check-input" type="checkbox" checked value="" id="defaultCheck1" />
                        <label className="form-check-label ms-2" for="defaultCheck1">
                            <p className='font-[300] mb-0'>Reserve price</p>
                        </label>
                    </div>
                </div>
                <div className='mt-4'>
                    <div className="row gx-md-4 gx-2">
                        <div className="col-md-3 col-6">
                            <div className="dropdown">
                                <div onClick={() => setIsActive1(!isActive1)} className="dropdown-btn">
                                    <span className='text-[#4D9AFF] flex items-center'>
                                        <img src={selected1.image} alt={selected1.text} className='me-2' />
                                        {selected1.text}
                                    </span>
                                    <span className={`text-white ${isActive1 ? "fas fa-chevron-up" : "fas fa-chevron-down"}`} />
                                </div>
                                <div className="dropdown-menu mt-2" style={{ display: isActive1 ? "block" : "none" }}>
                                    <div className="dropdown-item" onClick={() => handleDropdownItemClick1("Bitcoin", "/assets/images/create/image 6.png")}>
                                        <div className='flex items-center'>
                                            <Image src={image6} className='me-2' alt="Bitcoin" />Bitcoin
                                        </div>
                                    </div>
                                    <div className="dropdown-item" onClick={() => handleDropdownItemClick1("ETH", "/assets/images/create/image 7.png")}>
                                        <div className='flex items-center'>
                                            <Image src={image7} className='me-2' alt="ETH" />ETH
                                        </div>
                                    </div>
                                    <div className="dropdown-item" onClick={() => handleDropdownItemClick1("Cardano", "/assets/images/create/image 8.png")}>
                                        <div className='flex items-center'>
                                            <Image src={image8} className='me-2' alt="Cardano" />Cardano
                                        </div>
                                    </div>
                                    <div className="dropdown-item" onClick={() => handleDropdownItemClick1("Solona", "/assets/images/create/image 9.png")}>
                                        <div className='flex items-center'>
                                            <Image src={image9} className='me-2' alt="Solona" />Solona
                                        </div>
                                    </div>
                                    <div className="dropdown-item" onClick={() => handleDropdownItemClick1("Binance", "/assets/images/create/image 10.png")}>
                                        <div className='flex items-center'>
                                            <Image src={image10} className='me-2' alt="Binance" />Binance
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-9 col-6">
                            <input type="text" placeholder='0.058' className='py-[11px] px-4 w-100 bg-[#1B1830] rounded border-0 outline-none' />
                            <label htmlFor="" className='text-end block mt-3 text-[#9E9DA6CC]'>$860.00</label>
                        </div>
                    </div>
                </div>
                <div className="fees mt-5">
                    <p>Fees</p>
                    <div className='flex items-center justify-between text-[#FFFFFF80] border-b border-b-[#FFFFFF1A] pb-3 mb-3'>
                        <span>Service fee</span>
                        <span>2.5%</span>
                    </div>
                    <div className='flex items-center justify-between text-[#FFFFFF80]'>
                        <span>Creator fee</span>
                        <span>1%</span>
                    </div>
                </div>
                <a href="#" className='w-100 text-center py-3 mt-5 theme_btn'>Complete listing</a>
            </form>
        </div>
    );
}

export default AuctionForm;
