import React, { useState } from 'react'
import { FaChevronLeft } from "react-icons/fa6";
// import SaleForm from './SaleForm';
// import AuctionForm from './AuctionForm';
import { TbClock2 } from "react-icons/tb";
import { BiSolidDollarCircle } from "react-icons/bi";

import dynamic from 'next/dynamic';
const SaleForm = dynamic(() => import('./SaleForm'))
const AuctionForm = dynamic(() => import('./AuctionForm'))
import shadow2 from '@assets/images/home/shadow2.png'
import shadow3 from '@assets/images/home/shadow3.png'
import explore6 from '@assets/images/home/explore6.png'
import collection3 from '@assets/images/home/collection3.jpg'
import banner1 from '@assets/images/home/banner1.png'
import user from '@assets/images/offer/user.png'
import Image from 'next/image'

const SaleItemDetail = () => {

    const [card, setCard] = useState({
        id1: 'nav-Fixed',
        id2: 'nav-Auction'
    })

    const [number, setNumber] = useState(1)

    console.log("numver", number);

    return (
        <div className='sale_item py-[50px] relative'>
            <div className="container">
                <div className="shadows absolute d-md-block d-none left-[0px] bottom-[-500px] rotate-[-77.84 deg] opacity-[0.64] -z-10">
                    <Image src={shadow2} alt="shadow2" />
                </div>
                <div className="shadows absolute d-md-block d-none right-[0px] bottom-[-600px] rotate-[-48.95 deg] opacity-[0.64] -z-10">
                    <Image src={shadow3} alt="shadow3" />
                </div>
                <div className="prev_menu flex items-center gap-3 border-b border-b-[#FFFFFF1A] pb-4 mb-4">
                    <a href="/property"><FaChevronLeft className='text-white' /></a>
                    <Image src={explore6} className='w-16 rounded-[5px]' alt="explore6" />
                    <div>
                        <p className='mb-0 font-[300]'>SYNTHTOPIA</p>
                        <span className='text-[#C4C4C4]'>Shades of Space</span>
                    </div>
                </div>
                <div className="preview">
                    <div className="row gy-4">
                        {
                            number === 1 ?
                                <>
                                    <div className="col-xl-3 col-lg-4 col-md-6">
                                        <h1 className='text-[22px] mb-3'>Preview</h1>
                                        <div className="card text-white relative z-10 rounded-[5px] overflow-hidden theme_border">
                                            <div className="overflow-hidden rounded-[5px_5px_0_0]">
                                                <Image src={collection3} className='md:h-[219px] object-cover scale-110 rounded-[5px_5px_0_0]' alt="collection3" />
                                            </div>
                                            <div className="card-body bg-[#0D0B20] flex items-center justify-between rounded-[0_0_5px_5px]">
                                                <div>
                                                    <p className="card-title">Shades of Space</p>
                                                    <p className="card-text font-[300] text-sm text-[#FFFFFF99]">Price $80</p>
                                                </div>
                                                <a href="#" className="theme_btn px-[30px] py-2">Buy</a>
                                            </div>
                                        </div>
                                    </div>
                                </> :
                                <>
                                    <div className="col-xl-3 col-lg-4 col-md-6 collection_cards">
                                        <h1 className='text-[22px] mb-3'>Preview</h1>
                                        <div className="cards rounded-[5px] overflow-hidden theme_border">
                                            <div className='relative'>
                                                <Image src={banner1} className='md:h-[219px] object-cover w-100 rounded-[5px_5px_0_0]' alt='banner1' />
                                                <div className="card_layer flex justify-center w-100">
                                                    <p className='mb-0 text-[#FFFFFF99] bg-[#000000B2] py-2 px-4 rounded-md font-[300]'>10d : 20h : 10m : 25s</p>
                                                </div>
                                            </div>
                                            <div className="auction_info bg-[#0D0B20] rounded-[0_0_5px_5px] p-3">
                                                <div className='flex items-center gap-3 border-b border-[#FFFFFF1A] pb-3'>
                                                    <Image src={user} alt="user" />
                                                    <div>
                                                        <p className='mb-0 flex items-center'>Shades of Space</p>
                                                        <span className='theme_text text-sm'>By you</span>
                                                    </div>
                                                </div>
                                                <div className='flex items-center justify-between text-sm pt-3'>
                                                    <p className='mb-0'>Highest bid</p>
                                                    <span>$650.90</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                        }
                        <div className="col-xl-9 col-lg-8 ps-lg-5 font-[300]">
                            <h1 className='text-[28px] mb-4'>List item for sale</h1>
                            <p>Type</p>
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active col-6" id="nav-Fixed-tab" data-bs-toggle="tab" data-bs-target={`#${card.id1}`} type="button" role="tab" aria-controls="nav-Fixed" aria-selected="true" onClick={() => { setNumber(1) }}>
                                        <div className='flex items-center justify-center'>
                                            <BiSolidDollarCircle className='me-2 text-xl' />Fixed Price
                                        </div>
                                    </button>
                                    <button class="nav-link col-6" id="nav-Auction-tab" data-bs-toggle="tab" data-bs-target={`#${card.id2}`} type="button" role="tab" aria-controls="nav-Auction" aria-selected="false" onClick={() => { setNumber(2) }}>
                                        <div className='flex items-center justify-center'>
                                            <TbClock2 className='me-2 text-xl' />Auction
                                        </div>
                                    </button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id={card.id1} role="tabpanel" aria-labelledby="nav-Fixed-tab" tabindex="0">
                                    <SaleForm />
                                </div>
                                <div class="tab-pane fade" id={card.id2} role="tabpanel" aria-labelledby="nav-Auction-tab" tabindex="0">
                                    <AuctionForm />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SaleItemDetail