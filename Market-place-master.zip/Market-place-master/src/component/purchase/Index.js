import React from 'react'
// import Header from '../header/header'
// import Footer from '../footer/footer'
// import FixedMenu from '../header/FixedMenu'
// import Purchase from './Purchase'
import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const Purchase = dynamic(() => import('./Purchase'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <Purchase />
            <Footer />
        </div>
    )
}

export default Index