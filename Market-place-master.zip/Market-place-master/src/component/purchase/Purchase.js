import React, { useState } from 'react'
// import PurchaseItem from '../common/PurchaseItem';
import dynamic from 'next/dynamic';
const PurchaseItem = dynamic(() => import('../common/PurchaseItem'))
import shadow1 from '@assets/images/home/shadow1.png'
import purchase1 from '@assets/images/offer/purchase1.png'
import group from '@assets/images/offer/Group.png'
import purchase2 from '@assets/images/offer/purchase2.png'
import Image from 'next/image'

const Purchase = () => {

    const [quantities, setQuantities] = useState([0, 0]);

    const handleIncrement = (index) => {
        const newQuantities = [...quantities];
        newQuantities[index]++;
        setQuantities(newQuantities);
    };

    const handleDecrement = (index) => {
        if (quantities[index] > 0) {
            const newQuantities = [...quantities];
            newQuantities[index]--;
            setQuantities(newQuantities);
        }
    };

    return (
        <div className='purchase py-[50px] relative'>
            <div className="container">
                <div className="img_shadow absolute d-md-block d-none lg:top-[-80px] top-0 blur-lg right-[100px] -z-10">
                    <Image src={shadow1} alt="shadow1" />
                </div>
                <h3 className='mb-5 border-b pb-3 border-[#FFFFFF1A]'>Purchase Floyx NFTs</h3>

                <div className="row gy-4">
                    <div className="col-md-6">
                        <div className="purchase_card bg-[#0D0B20] h-100">
                            <div className="row g-0 h-100">
                                <div className="col-lg-6">
                                    <Image src={purchase1} className='w-100 h-100 object-cover' alt='purchase1' />
                                </div>
                                <div className="col-lg-6">
                                    <div className='purchase_info p-4'>
                                        <div className='flex items-center'>
                                            <div className='w-9 h-9 bg-[#23203E] rounded-sm flex items-center justify-center'><Image src={group} alt="Group" /></div>
                                            <div className='ps-3'>
                                                <p className='mb-0'>Shades - Rare</p>
                                                <span className='theme_text text-sm'>By Floyx</span>
                                            </div>
                                        </div>
                                        <p className='font-[300] text-sm my-4 text-[#FFFFFF99]'>The card is <b className='text-white'>level 0</b>. It serves as a basic card whose level can be increased through the appropriate number of Boosters. The higher the level, the more benefits users receive both in staking and on the Floyx platform. For more on the level increase system, see <a href="#" className='text-[#4D9AFF] border-b border-b-[#4D9AFF]'>Upgrade Floyx NFT</a>.</p>
                                        <div className='flex items-center justify-between mb-4'>
                                            <p className='mb-0'>Price $100</p>
                                            <p className='mb-0 text-[#FFFFFF99] font-[300] text-sm'>Available: 120 pcs</p>
                                        </div>
                                        <div className='row'>
                                            <div className='col-6'>
                                                <div className='border py-2 rounded-md flex border-[#FFFFFF1A] items-center'>
                                                    <button className='flex-grow text-center' onClick={() => handleDecrement(0)}>-</button>
                                                    <span className='flex-grow text-center'>{quantities[0]}</span>
                                                    <button className='flex-grow text-cente' onClick={() => handleIncrement(0)}>+</button>
                                                </div>
                                            </div>
                                            <div className='col-6'>
                                                <a type='button' data-bs-toggle="modal" data-bs-target="#purchaseItem" className='theme_btn py-2 text-center w-100'>Buy</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="purchase_card bg-[#0D0B20] h-100">
                            <div className="row g-0 h-100">
                                <div className="col-lg-6">
                                    <Image src={purchase2} className='w-100 h-100 object-cover' alt='purchase2' />
                                </div>
                                <div className="col-lg-6">
                                    <div className='purchase_info p-4'>
                                        <div className='flex items-center'>
                                            <div className='w-9 h-9 bg-[#23203E] rounded-sm flex items-center justify-center'><Image src={group} alt="Group" /></div>
                                            <div className='ps-3'>
                                                <p className='mb-0'>Shades - Booster</p>
                                                <span className='theme_text text-sm'>By Floyx</span>
                                            </div>
                                        </div>
                                        <p className='font-[300] text-sm my-4 text-[#FFFFFF99]'>The card is used to increase the levels of your <b className='text-white'>RARE card</b>. The higher the level, the more benefits users receive both in staking and onthe Floyx platform.</p>
                                        <p className='font-[300] text-sm my-4 text-[#FFFFFF99]'>For more on the level increase system, see Upgrade Floyx NFT <a href="#" className='text-[#4D9AFF] border-b border-b-[#4D9AFF]'>Upgrade Floyx NFT</a>.</p>
                                        <div className='flex items-center justify-between mb-4'>
                                            <p className='mb-0'>Price $10</p>
                                            <p className='mb-0 text-[#FFFFFF99] font-[300] text-sm'>Available: 150 pcs</p>
                                        </div>
                                        <div className='row'>
                                            <div className='col-6'>
                                                <div className='border py-2 rounded-md flex border-[#FFFFFF1A] items-center'>
                                                    <button className='flex-grow text-center' onClick={() => handleDecrement(1)}>-</button>
                                                    <span className='flex-grow text-center'>{quantities[1]}</span>
                                                    <button className='flex-grow text-cente' onClick={() => handleIncrement(1)}>+</button>
                                                </div>
                                            </div>
                                            <div className='col-6'>
                                                <a type='button' data-bs-toggle="modal" data-bs-target="#purchaseItem" className='theme_btn py-2 text-center w-100'>Buy</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <PurchaseItem />
        </div>
    )
}

export default Purchase