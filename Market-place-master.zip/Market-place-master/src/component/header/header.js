import React, { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/router';
import { RiSearchLine } from "react-icons/ri";
import Link from 'next/link';
import { PiBagLight } from "react-icons/pi";
// import OffCanvas from './OffCanvas';
// import Creates from '../create/Index';
// import CartModal from '../common/CartModal';
import logo from '@assets/images/logo.png'
import banner1 from '@assets/images/home/banner1.png'
import collection2 from '@assets/images/home/collection2.png'
import user from '@assets/images/offer/user.png'
import collection1 from '@assets/images/collection/collection1.jpg'
import Image from 'next/image';

import dynamic from 'next/dynamic'

const OffCanvas = dynamic(() => import('./OffCanvas'))
const Creates = dynamic(() => import('../create/Index'))
const CartModal = dynamic(() => import('../common/CartModal'))

const Header = ({ head, cart }) => {

    const router = useRouter();
    const [click, setClick] = useState(false);

    const [showSearchOptions, setShowSearchOptions] = useState(false);
    const inputRef = useRef(null);

    const handleInputFocus = () => {
        setShowSearchOptions(true);
    };

    const handleClickOutside = (event) => {
        if (!inputRef.current.contains(event.target) && !event.target.closest(".search_option")) {
            setShowSearchOptions(false);
        }
    };


    useEffect(() => {
        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, []);

    // const location = useLocation();

    return (
        <div>
            <div className='d-lg-block d-none'>
                <nav className="navbar py-4" onClick={e => e.stopPropagation()}>
                    <div className="container">
                        <Link href="/" className="nav-logo">
                            <Image src={logo} alt="logo" />
                        </Link>
                        <ul className={click ? "nav-menu active" : "nav-menu"}>
                            <li className="nav-item">
                                <Link href="/drops" className={`nav-links ${router.pathname === '/drops' ? 'active' : ''}`}>
                                    Drops
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link href="#" type='button' data-bs-toggle="modal" data-bs-target={`#${head}`} className="nav-links">
                                    Create
                                </Link>
                                <Creates create={head} />
                            </li>

                            <li className='search'>
                                <form className='relative'>
                                    <input type="text" placeholder='Search' ref={inputRef} onFocus={handleInputFocus} />
                                    <RiSearchLine className='search_icon' />
                                    {showSearchOptions && (
                                        <div className="search_option">
                                            <ul>
                                                <p className='text-start'>Collection</p>
                                                <li className='mb-3'>
                                                    <a href="#" className='flex items-center'>
                                                        <div className='theme_border w-[50px] h-[40px]'>
                                                            <Image src={banner1} alt="banner1" className=' rounded-[5px] h-100 w-100 object-cover' />
                                                        </div>
                                                        <span className='font-[300] text-[#FFFFFF99] ms-3'>Shades of Space</span>
                                                    </a>
                                                </li>
                                                <li className='mb-3'>
                                                    <a href="#" className='flex items-center'>
                                                        <div className='theme_border w-[50px] h-[40px]'>
                                                            <Image src={collection2} alt="collection2" className='rounded-[5px] h-100 w-100 object-cover' />
                                                        </div>
                                                        <span className='font-[300] text-[#FFFFFF99] ms-3'>Shades black</span>
                                                    </a>
                                                </li>
                                                <p className='text-start'>User</p>
                                                <li className='mb-3'>
                                                    <a href="/collection-detail" className='flex items-center'>
                                                        <div className='theme_border w-[50px] h-[40px]'>
                                                            <Image src={user} alt="user" className=' rounded-[5px] h-100 w-100 object-cover' />
                                                        </div>
                                                        <span className='font-[300] text-[#FFFFFF99] ms-3'>Shades_697</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="/collection-detail" className='flex items-center'>
                                                        <div className='theme_border w-[50px] h-[40px]'>
                                                            <Image src={collection1} alt="collection1" className=' rounded-[5px] h-100 w-100 object-cover' />
                                                        </div>
                                                        <span className='font-[300] text-[#FFFFFF99] ms-3'>Shades_david</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    )}
                                </form>
                            </li>
                        </ul>
                        <div className="sign_menu flex items-center">
                            <Link href="/sign-up">Sign up</Link>
                            <Link href="/login">Login</Link>
                            <Link href="#" data-bs-toggle="modal" data-bs-target={`#${cart}`}><PiBagLight /></Link>
                            <CartModal cart={cart} />
                        </div>
                        {/* <div className="nav-icon" onClick={handleClick}>
                            <i className={click ? "fa fa-times" : "fa fa-bars"}></i>
                        </div> */}
                    </div>
                </nav>
            </div>
            <OffCanvas sidebar="sideMenu" cart="sideCart" />
        </div>
    );
}

export default Header