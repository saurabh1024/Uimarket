'use client'

import React from 'react'
import Link from 'next/link'

const MenuBar = () => {
    return (
        <div>
            {/* menu start */}
            <div className="container">
                <ul className="nav overflow-x-auto whitespace-nowrap flex-nowrap menu border-b border-b-[#FFFFFF1A]">
                    <li className="nav-item">
                        <Link className="text-[#5499FF] pb-4 hover:text-[#5499FF] pe-4 block active" aria-current="page" href="#">All</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">Art</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">Gaming</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">Memberships</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">PFPs</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">Photography</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="#">Music</Link>
                    </li>
                    {/* other option */}
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="/property">Property</Link>
                    </li>
                    <li className="nav-item">
                        <Link className="text-[#FFFFFF99] pb-4 hover:text-[#5499FF] pe-4 block" href="/activity">Activity</Link>
                    </li>
                </ul>
            </div>
        </div>
    )
}

export default MenuBar