import React, { useState, useEffect } from 'react'
import { MdOutlineLocalOffer, MdChevronRight } from "react-icons/md";
import { TbClock2, TbShieldHalf, TbSettings } from "react-icons/tb";
import { HiOutlineShoppingBag, HiOutlineSquare2Stack } from "react-icons/hi2";
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css'
import Link from 'next/link';
import { useRouter } from 'next/router';

const menu = [
    {
        id: 1,
        icon: <MdOutlineLocalOffer />,
        tooltip: 'Offer',
        link: '/offers',
        component: () => import('../offers/Index')
    },
    {
        id: 2,
        icon: <TbClock2 />,
        tooltip: 'Auctions',
        link: '/auctions',
        component: () => import('../auctions/Index')
    },
    {
        id: 3,
        icon: <HiOutlineShoppingBag />,
        tooltip: 'Purchase',
        link: '/purchase',
        component: () => import('../purchase/Index')
    },
    {
        id: 4,
        icon: <TbShieldHalf />,
        tooltip: 'Floyx NFT',
        link: '/floyx-nft',
        component: () => import('../floyx-nft/Index')
    },
    {
        id: 5,
        icon: <HiOutlineSquare2Stack />,
        tooltip: 'My Collection',
        link: '/collection',
        component: () => import('../collection/Index')
    },
    {
        id: 6,
        icon: <TbSettings />,
        tooltip: 'Account Setting',
        link: '/account-setting',
        component: () => import('../account/Index')
    }
]

const FixedMenu = () => {

    const [show, setShow] = useState(false)

    const showMenu = () => {
        setShow(!show)
    }

    const router = useRouter();

    return (
        <div className='fixed_menu fixed left-0 top-[200px] z-50'>
            <button id="toggleButton" onClick={showMenu} className={`w-5 z-10 rotate-${show ? '180' : '0'} h-5 bg-${show ? 'blue-500' : 'white'} rounded-full text-black flex items-center justify-center absolute top-1/2 translate-y-[-50%] right-[-10px]`}><MdChevronRight /></button>
            <ul id="menu" className={`backdrop-blur-md flex flex-col justify-around rounded-[0_5px_5px_0] w-${show ? '16' : '7'} h-[350px] text-center`}>
                {
                    menu.map((res) => {
                        return (
                            <li key={res.id} className='py-3 px-sm-2 px-1' data-bs-toggle="tooltip" data-bs-placement="right" data-bs-title="Tooltip on right">
                                <Link href={res.link}
                                    data-tooltip-id="my-tooltip"
                                    data-tooltip-content={res.tooltip}
                                    data-tooltip-place="right"
                                    className={`text-2xl text-[#FFFFFF99] flex justify-center ${router.pathname === `${res.link}` ? 'active' : ''}`}>
                                    {show && <>{res.icon}</>}
                                </Link>
                            </li>
                        )
                    })
                }
            </ul>
            <Tooltip id="my-tooltip" />
        </div>

    )
}

export default FixedMenu
