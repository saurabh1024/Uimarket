import React from 'react'
// import Header from '../../header/header'
// import Footer from '../../footer/footer'
// import FixedMenu from '../../header/FixedMenu'
// import MintDetail from './MintDetail'

import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../../header/header'))
const FixedMenu = dynamic(() => import('../../header/FixedMenu'))
const MintDetail = dynamic(() => import('./MintDetail'))
const Footer = dynamic(() => import('../../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <MintDetail />
            <Footer />
        </div>
    )
}

export default Index