import React from 'react'
// import Header from '../header/header'
// import FixedMenu from '../header/FixedMenu'
// import Footer from '../footer/footer'
// import Account from './Account'
import dynamic from 'next/dynamic'

const Header = dynamic(() => import('../header/header'))
const FixedMenu = dynamic(() => import('../header/FixedMenu'))
const Account = dynamic(() => import('./Account'))
const Footer = dynamic(() => import('../footer/footer'))

const Index = () => {
    return (
        <div>
            <Header head="headModal" cart="cartModal" />
            <FixedMenu />
            <Account />
            <Footer />
        </div>
    )
}

export default Index