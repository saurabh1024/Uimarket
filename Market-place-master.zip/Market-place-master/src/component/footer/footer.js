import React from 'react'
import footer_logo from '@assets/images/footer_logo.png'
import Image from 'next/image';

const Footer = () => {
    return (
        <div className='footer bg-[#0B081E] py-[50px]'>
            <div className="container border-b border-[#FFFFFF2B] pb-5">
                <div className="row gy-4">
                    <div className="col-md-4">
                        <a href="/">
                            <Image src={footer_logo} className='' alt="footer_logo" />
                        </a>
                    </div>
                    <div className="col-md-8">
                        <div className="row gy-4 row-cols-lg-5 row-cols-sm-3 row-cols-2">
                            <div className="col">
                                <div className="footer_info">
                                    <p>Products</p>
                                    <ul>
                                        <li><a href="#">Launchpad</a></li>
                                        <li><a href="#">SocialFi</a></li>
                                        <li><a href="#">Marketplace</a></li>
                                        <li><a href="#">NFT Airdrops</a></li>
                                        <li><a href="#">DEX Buy</a></li>
                                        <li><a href="#">Floyx Tokens</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col">
                                <div className="footer_info">
                                    <p>Company</p>
                                    <ul>
                                        <li><a href="#">Brand Assets</a></li>
                                        <li><a href="#">Partners</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col">
                                <div className="footer_info">
                                    <p>Resources</p>
                                    <ul>
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">FAQ</a></li>
                                        <li><a href="#">Support</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col">
                                <div className="footer_info">
                                    <p>Social</p>
                                    <ul>
                                        <li><a href="#">Twitter</a></li>
                                        <li><a href="#">Telegram</a></li>
                                        <li><a href="#">Discord</a></li>
                                        <li><a href="#">Instagram</a></li>
                                        <li><a href="#">Facebook</a></li>
                                        <li><a href="#">TikTok</a></li>
                                        <li><a href="#">YouTube</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col">
                                <div className="footer_info">
                                    <p>Legal</p>
                                    <ul>
                                        <li><a href="#">Terms</a></li>
                                        <li><a href="#">Privacy</a></li>
                                        <li><a href="#">Cookies</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container border-b border-[#FFFFFF2B]">
                <div className="row">
                    <div className="col">
                        <p className='text-[#848895] py-[40px]'>This web page and any other contents published on this website shall not constitute investment advice, financial advice, trading advice, or any other kind of advice, and you should not treat any of the website's content as such. You alone assume the sole responsibility of evaluating the merits and risks associated with using any information or other content on this website before making any decisions based on such information. You understand that the crypto market is characterised by high volatility, and you should be aware of the concrete possibility of losing the entirety of the funds you allocated in the crypto market. You should refrain from using funds you can't afford to lose when purchasing cryptocurrencies and other digital tokens.</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Footer