import React from 'react'
import dynamic from 'next/dynamic'
import { TbSettings } from "react-icons/tb";
// import CollectionSlide from './CollectionSlide';
import Link from 'next/link';

const CollectionSlide = dynamic(() => import('./CollectionSlide'))
import collection1 from '@assets/images/collection/collection1.jpg'
import collection2 from '@assets/images/collection/collection2.jpg'
import collection3 from '@assets/images/collection/collection3.jpg'
import collection4 from '@assets/images/collection/collection4.jpg'
import collection5 from '@assets/images/collection/collection5.jpg'
import Image from 'next/image';

const collection_card = [
    {
        id: 1,
        img1: collection1,
        title: 'Shades of Space',
        item: 25,
        img2: collection2,
        img3: collection3,
        img4: collection4,
        img5: collection5,
    },
    {
        id: 2,
        img1: collection1,
        title: 'Shades of Space',
        item: 25,
        img2: collection2,
        img3: collection3,
        img4: collection4,
        img5: collection5,
    },
    {
        id: 3,
        img1: collection1,
        title: 'Shades of Space',
        item: 25,
        img2: collection2,
        img3: collection3,
        img4: collection4,
        img5: collection5,
    }
]

const MyCollections = () => {
    return (
        <div>
            <div className="collection">
                <div className="row gy-4">
                    {
                        collection_card.map((res, index) => {
                            return (
                                <>
                                    <div className="col-lg-4 col-md-6" key={index}>
                                        <div className="collection-card">
                                            <div className="flex items-center justify-between mb-3">
                                                <div className='flex items-center'>
                                                    <div className='cursor-pointer' data-bs-toggle="modal" data-bs-target="#CollectionItem">
                                                        <Image src={res.img1} className='w-[52px] rounded-[5px]' alt="colllection1" />
                                                    </div>
                                                    <div className='ms-3'>
                                                        <p className='mb-0'>{res.title}</p>
                                                        <span className='text-[#FFFFFF99] text-sm'>{res.item} Items</span>
                                                    </div>
                                                </div>
                                                <Link href="/account-setting"><TbSettings className='text-[#FFFFFF99] text-2xl' /></Link>
                                            </div>
                                            <div className="row g-2">
                                                <div className="col-6">
                                                    <Image src={res.img2} className='w-full h-full rounded-[5px] object-cover' alt="colllection2" />
                                                </div>
                                                <div className="col-6">
                                                    <div className="row g-2">
                                                        <div className="col-6">
                                                            <Image src={res.img3} className='rounded-[5px]' alt="colllection3" />
                                                        </div>
                                                        <div className="col-6">
                                                            <Image src={res.img4} className='rounded-[5px]' alt="colllection4" />
                                                        </div>
                                                        <div className="col-12">
                                                            <Image src={res.img5} className='rounded-[5px]' alt="colllection5" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )
                        })
                    }
                </div>
            </div>
            <CollectionSlide />
        </div>
    )
}

export default MyCollections