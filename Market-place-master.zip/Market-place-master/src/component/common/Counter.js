import React, { useEffect, useState } from 'react'
import dynamic from 'next/dynamic' // Import dynamic from next/dynamic

const CountUp = dynamic(() => import('react-countup'), { ssr: false })

const Counter = () => {
  const [options, setOptions] = useState(null)

  useEffect(() => {
    // Set carousel options after component mounts
    setOptions({
      first: 90,
      second: 120,
      thrid: 120,
      forth: 850,
    })
  }, [])

  return (
    <div className='theme_bg mb-5'>
      <div className='counter'>
        <div className='row gy-5 text-center'>
          <div className='col-lg-3 col-6'>
            <p className='text-[#9E9DA6] text-sm'>Total Supply</p>
            <h1 className='mb-0'>
              <CountUp end={options?.first} />
              <span className='text-[#4D9AFF]'>M</span>
            </h1>
          </div>
          <div className='col-lg-3 col-6'>
            <p className='text-[#9E9DA6] text-sm'>Owners</p>
            <h1 className='mb-0'>
              <CountUp end={options?.second} />
              <span className='text-[#4D9AFF]'>K+</span>
            </h1>
          </div>
          <div className='col-lg-3 col-6'>
            <p className='text-[#9E9DA6] text-sm'>Floor Price</p>
            <h1 className='mb-0'>
              <span className='text-[#4D9AFF]'>$</span>
              <CountUp end={options?.thrid} />
            </h1>
          </div>
          <div className='col-lg-3 col-6'>
            <p className='text-[#9E9DA6] text-sm'>Volume Traded</p>
            <h1 className='mb-0'>
              <CountUp end={options?.forth} />
              <span className='text-[#4D9AFF]'>K+</span>
            </h1>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Counter
