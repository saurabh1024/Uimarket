import Image from 'next/image'
import Link from 'next/link'
import React from 'react'
import verify from '@assets/images/home/verify.png'
import collection3 from '@assets/images/home/collection3.png'
import collection2 from '@assets/images/home/collection2.png'
import collection1 from '@assets/images/home/collection1.png'

const collection_card = [
    {
        id: 1,
        image: collection3,
        title: 'Shades of Space',
        price: '$80',
    },
    {
        id: 2,
        image: collection2,
        title: 'Dream Scape',
        price: '$80'
    },
    {
        id: 3,
        image: collection1,
        title: 'Ether & Era',
        price: '$80'
    }
]

const TopCollection = () => {
    return (
        <div className='top_collection py-[50px]'>
            <div className="container">
                <h3 className='mb-5'>Top Collection</h3>
                <div className="collection_cards">
                    <div className="row gy-4 justify-content-center">
                        {
                            collection_card.map((res) => {
                                return (
                                    <>
                                        <div className="col-lg-4 col-md-6" key={res.id}>
                                            <Link href="/collection-detail">
                                                <div className="cards theme_border">
                                                    <Image src={res.image} className='w-100 rounded-[5px] h-100' alt={res.title} />
                                                    <div className="card_layer bg-[linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.9) 86.84%)]">
                                                        <div>
                                                            <p className='mb-2 text-lg flex items-center text-white'>{res.title} <Image src={verify} alt="verify" className='ms-2' /></p>
                                                            <p className='mb-0 text-[#FFFFFF99] font-[300]'>Price <span>{res.price}</span></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </Link>
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}

export default TopCollection