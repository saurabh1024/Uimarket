import Image from 'next/image'
import React from 'react'
import shadow1 from '@assets/images/home/shadow1.png'
import banner1 from '@assets/images/home/banner1.png'
import banner2 from '@assets/images/home/banner2.png'
import banner3 from '@assets/images/home/banner3.png'

const HomeBanner = () => {
    return (
        <div className='home_banner py-[50px]'>
            <div className="container">
                <div className="row gy-5">
                    <div className="col-lg-5">
                        <div className="home_text">
                            <h1>Explore Our</h1>
                            <h1 className='theme_text'>NFT Universe</h1>
                            <p className='mt-3'>Start your NFT journey with us! & own a piece of the future</p>
                            <a href="#" className='theme_btn px-5 py-3 mt-4'>Get Started</a>
                        </div>
                    </div>
                    <div className="col-lg-7">
                        <div className="banner_card relative">
                            <div className="img_shadow absolute sm:top-[120px] md:top-[100px] xl:top-[50px] top-[10px] blur-lg sm:left-0 left-[-200px] -z-10">
                                <Image src={shadow1} alt="shadow1" />
                            </div>
                            <div className="img_shadow absolute top-[-120px] d-md-block d-none  sm:right-[-5px] right-[-100px] -z-10">
                                <Image src={shadow1} alt="shadow1" />
                            </div>
                            <div className='hero_area'>
                                <div className="card_img absolute left-0 top-0 d-sm-block d-none">
                                    <Image src={banner3} alt="banner3" />
                                </div>
                                <div className="card text-white relative z-10 theme_border">
                                    <Image src={banner1} alt="banner1" className='rounded-[5px_5px_0_0]' />
                                    <div className="card-body bg-[#0D0B20] flex items-center justify-between rounded-[0_0_5px_5px]">
                                        <div>
                                            <p className="card-title">Shades of Space</p>
                                            <p className="card-text font-[300] text-sm text-[#FFFFFF99]">Price $80</p>
                                        </div>
                                        <a href="#" className="theme_btn px-[30px] py-2">Buy</a>
                                    </div>
                                </div>
                                <div className="card_img absolute right-0 top-0 d-sm-block d-none">
                                    <Image src={banner2} alt="banner2" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HomeBanner