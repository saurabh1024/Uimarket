import React from 'react'
import Index from '../../component/account/Index'

const AccountSetting = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default AccountSetting
