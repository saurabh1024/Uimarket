import React from 'react'
import Index from '../../component/floyx-nft/Index'

const FloyxNft = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default FloyxNft