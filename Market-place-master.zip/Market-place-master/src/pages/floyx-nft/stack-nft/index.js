import React from 'react'
// import Index from '../../component/floyx-nft/stack-nft/Index'
import Index from '../../../component/floyx-nft/stack-nft/Index'

const StackNft = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default StackNft
