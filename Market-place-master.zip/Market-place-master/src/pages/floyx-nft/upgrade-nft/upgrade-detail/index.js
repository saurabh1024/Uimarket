import React from 'react'
import Index from '../../../../component/floyx-nft/component/UpgradeDetails/Index'

const UpgradeDetails = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default UpgradeDetails
