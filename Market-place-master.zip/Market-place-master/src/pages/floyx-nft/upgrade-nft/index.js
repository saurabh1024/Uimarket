import React from 'react'
import Index from '../../../component/floyx-nft/component/Index'

const UpdradeNft = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default UpdradeNft
