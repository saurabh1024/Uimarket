import React from 'react'
import Index from '../../component/login/Index'

const Login = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Login