import React from 'react'
import Index from '../../component/home';
const Home = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Home