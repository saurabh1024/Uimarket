import React from 'react'
import Index from '../../component/drops'

const Drops = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Drops