import React from 'react'
import Index from '../../component/purchase/Index'

const Purchase = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Purchase