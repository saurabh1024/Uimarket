import React from 'react'
// import Index from '../component/collection/Index'
import Index from '@/component/collection/Index'

const Collection = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default Collection
