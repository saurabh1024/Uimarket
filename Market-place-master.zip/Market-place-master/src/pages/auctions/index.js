import React from 'react'
import Index from '../../component/auctions/Index'

const Auctions = () => {
    return (
        <div>
            <Index/>
        </div>
    )
}

export default Auctions