import React from 'react'
import Index from '../../component/details/collection-detail/Index'

const CollectionItemsDetail = () => {
    return (
        <div>
            <Index/>
        </div>
    )
}

export default CollectionItemsDetail