import React from 'react'
import Index from '../../component/activity/Index'

const Activity = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default Activity
