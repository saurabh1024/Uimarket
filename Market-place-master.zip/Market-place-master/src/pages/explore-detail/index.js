import React from 'react'
import Index from '../../component/details/explore-detail/Index'

const ExploreItemDetail = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default ExploreItemDetail
