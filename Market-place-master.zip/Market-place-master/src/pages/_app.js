import { useEffect } from 'react';
import '@/styles/globals.css';
import '../styles/scss/app.scss';
import 'bootstrap/dist/css/bootstrap.min.css';

function App({ Component, pageProps }) {
  useEffect(() => {
    import('bootstrap/dist/js/bootstrap.min.js');
  }, []);

  return <Component {...pageProps} />;
}

export default App;
