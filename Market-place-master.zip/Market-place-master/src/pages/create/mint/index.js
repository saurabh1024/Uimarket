import React from 'react'
import Index from '../../../component/create/mint/Index'

const Mint = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Mint