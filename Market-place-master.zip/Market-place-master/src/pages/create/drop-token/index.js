import React from 'react'
import Index from '../../../component/create/drop-token/Index'

const DropToken = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default DropToken