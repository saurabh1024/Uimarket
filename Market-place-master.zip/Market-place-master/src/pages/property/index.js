import React from 'react'
import Index from '../../component/property/Index'

const Property = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default Property
