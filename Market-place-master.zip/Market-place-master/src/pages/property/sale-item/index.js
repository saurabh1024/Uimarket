import React from 'react'
import Index from '../../../component/property/sale-item/Index'
const SaleItem = () => {
  return (
    <div>
      <Index />
    </div>
  )
}

export default SaleItem
