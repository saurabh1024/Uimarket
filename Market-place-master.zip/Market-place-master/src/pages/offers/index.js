import React from 'react'
import Index from '../../component/offers/Index'

const Offers = () => {
    return (
        <div>
            <Index/>
        </div>
    )
}

export default Offers