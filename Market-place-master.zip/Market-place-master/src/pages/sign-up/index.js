import React from 'react'
import Index from '../../component/register/Index'

const Register = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default Register